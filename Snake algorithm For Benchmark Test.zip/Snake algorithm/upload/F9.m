function [y] = F9(x)
    % x: D boyutlu vektör
    D = length(x);
    sum = 0;
    for i = 1:D
        sum = sum + x(i)^2 - 10 * cos(2 * pi * x(i)) + 10;
    end
    y = sum;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
