function [y] = F1(x)
    % Fonksiyonun boyutunu al (D)
    D = length(x);
    
    % Toplamı başlat
    sum = 0;
    
    % Her bir bileşenin karesini al ve topla
    for i = 1:D
        sum = sum + x(i)^2;
    end
    
    % Toplamı fonksiyon sonucu olarak döndür
    y = sum;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
