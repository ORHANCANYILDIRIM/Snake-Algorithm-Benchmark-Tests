function y = F12(x)
    % x: D boyutlu vektör
    D = length(x);
    sum1 = 0;
    sum2 = 0;
    for i = 1:(D-1)
        yi = 1 + 1/4 * (x(i) + 1);
        yi_plus_1 = 1 + 1/4 * (x(i+1) + 1);
        term = (yi - 1)^2 * (1 + 10 * sin(pi * yi_plus_1)^2);
        sum1 = sum1 + term;
    end
    yD = 1 + 1/4 * (x(D) + 1);
    term_last = (yD - 1)^2;
    sum1 = 10 * sin(pi * x(1))^2 + sum1 + term_last;
    
    for i = 1:D
        sum2 = sum2 + u(x(i), 10, 100, 4);
    end
    
    y = pi/D * sum1 + sum2;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end

function result = u(xi, a, k, m)
    if xi > a
        result = k * (xi - a)^m;
    elseif xi >= -a && xi <= a
        result = 0;
    else
        result = k * (-xi - a)^m;
    end
end
