function [y] = F10(x)
    % x: D boyutlu vektör
    D = length(x);
    sum1 = 0;
    sum2 = 0;
    for i = 1:D
        sum1 = sum1 + x(i)^2;
        sum2 = sum2 + cos(2 * pi * x(i));
    end
    term1 = -20 * exp(-0.2 * sqrt(1/D * sum1));
    term2 = -exp(1/D * sum2);
    y = term1 + term2 + 20 + exp(1);
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
