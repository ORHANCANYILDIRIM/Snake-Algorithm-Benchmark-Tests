function [y] = F8(x)
    D = length(x); % Vektörün boyutunu al
    
    % Toplamı başlat
    sum = 0;
    
    % Terimleri topla
    for i = 1:D
        term = -x(i) * sin(sqrt(abs(x(i))));
        sum = sum + term;
    end
    
    % Minimum değeri belirle
    f_min = 418.9829 * 5;
    
    % Toplamı fonksiyon sonucu olarak döndür, minimum değeri kontrol et
    y = max(sum, f_min);
end
