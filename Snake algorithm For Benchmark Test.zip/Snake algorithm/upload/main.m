close all
clear all
clc
fitfun = @F13;
dims = [10, 20, 30, 100, 500, 1000]; % Different values of dim
Max_iteration = 1000;
SearchAgents_no = 20;
lb = -50;
ub = 50;
% fitfun fonksiyonunun adını al
fitfun_name = func2str(fitfun);
tlt = fitfun_name;

all_fitness_values = zeros(length(dims), 30); % Store fitness values for each dimension and run
all_convergence_curves = cell(length(dims), 30); % Store convergence curves for each dimension and run
all_times = zeros(length(dims), 30); % Store execution times for each dimension and run

for dim_index = 1:length(dims)
    dim = dims(dim_index);
    disp(['Running for dim = ', num2str(dim)]);
    for run = 1:30
        disp(['Run ', num2str(run)]);
        tic; % Start timer
        [Xfood, Xvalue, CNVG] = SO(SearchAgents_no, Max_iteration, fitfun, dim, lb, ub);
        elapsedTime = toc; % Calculate elapsed time
        all_times(dim_index, run) = elapsedTime; % Store elapsed time
        all_fitness_values(dim_index, run) = Xvalue(end); % Store final fitness value
        all_convergence_curves{dim_index, run} = CNVG; % Store convergence curve
    end
end

% Write data to Excel file
filename = [fitfun_name '_optimizer_results.xlsx'];
output_data = cell(length(dims) * 30 + 1, 8); % +1 for header row
output_data{1, 1} = 'Dimension';
output_data{1, 2} = 'Run';
output_data{1, 3} = 'Fitness Value';
output_data{1, 4} = 'Convergence Curve';
output_data{1, 5} = 'Execution Time (s)';


row = 2; % Start from row 2 (after header)
for dim_index = 1:length(dims)
    dim = dims(dim_index);
    for run = 1:30
        output_data{row, 1} = dim;
        output_data{row, 2} = run;
        output_data{row, 3} = all_fitness_values(dim_index, run);
        output_data{row, 4} = all_convergence_curves{dim_index, run};
        output_data{row, 5} = all_times(dim_index, run);
        row = row + 1;
    end
    
    
end

writecell(output_data, filename);
disp(['Data has been written to ', filename]);


% Read the data from the Excel file
filename = [fitfun_name '_optimizer_results.xlsx'];
data = readcell(filename);

% Extract fitness values from the data
fitness_values = cell2mat(data(2:end, 3));

% Calculate statistics
average = mean(fitness_values);
minimum = min(fitness_values);
maximum = max(fitness_values);
median_val = median(fitness_values);
std_dev = std(fitness_values);

% Format the output
avg_str = sprintf('Avg %.2E', average);
min_str = sprintf('Min %.2E', minimum);
max_str = sprintf('Max %.2E', maximum);
med_str = sprintf('Med %.2E', median_val);
std_str = sprintf('STD %.2E', std_dev);

% Display the results
disp(avg_str);
disp(min_str);
disp(max_str);
disp(med_str);
disp(std_str);
% Ayrı bir Excel dosyası oluştur
statistics_filename = [fitfun_name '_dimension_statistics.xlsx'];
statistics_header = {'Dimension', 'Maximum Fitness', 'Minimum Fitness', 'Average Fitness', 'Median Fitness', 'Standard Deviation'};
statistics_data = cell(length(dims) + 1, length(statistics_header)); % +1 for header row
statistics_data(1, :) = statistics_header; % Header row

% Hesaplanan istatistiklerin Excel dosyasına yazılması
for dim_index = 1:length(dims)
    dim = dims(dim_index);
    dim_fitness_values = all_fitness_values(dim_index, :);
    
    max_fitness = max(dim_fitness_values);
    min_fitness = min(dim_fitness_values);
    avg_fitness = mean(dim_fitness_values);
    median_fitness = median(dim_fitness_values);
    std_dev = std(dim_fitness_values);
    
    % Verileri hücrelere yazma
    statistics_data{dim_index + 1, 1} = dim;
    statistics_data{dim_index + 1, 2} = max_fitness;
    statistics_data{dim_index + 1, 3} = min_fitness;
    statistics_data{dim_index + 1, 4} = avg_fitness;
    statistics_data{dim_index + 1, 5} = median_fitness;
    statistics_data{dim_index + 1, 6} = std_dev;
end

% Excel dosyasına yazma
writecell(statistics_data, statistics_filename);
disp(['Statistics data has been written to ', statistics_filename]);
figure;

% Boyutlar için yakınsama eğrilerinin ortalamalarını saklayacak matrisi oluştur
avg_convergence_curves = zeros(length(dims), numel(all_convergence_curves{1,1}));

for dim_index = 1:length(dims)
    dim = dims(dim_index);
    subplot(2, 3, dim_index);
    hold on;
    
    % Her bir çalıştırma için yakınsama eğrisini çiz
    for run = 1:30
        plot(all_convergence_curves{dim_index, run}, 'Color', rand(1, 3));
        
        % Ortalama eğriyi güncelle
        avg_convergence_curves(dim_index, :) = avg_convergence_curves(dim_index, :) + all_convergence_curves{dim_index, run};
    end
    
    % Ortalama eğriyi hesapla ve çiz
    avg_convergence_curves(dim_index, :) = avg_convergence_curves(dim_index, :) / 30;
    plot(avg_convergence_curves(dim_index, :), 'k', 'LineWidth', 2);
    
    hold off;
    title(['Convergence Curve for Dimension ', num2str(dim)]);
    xlabel('Iteration');
    ylabel('Fitness Value');
    grid on;
end

% Renkler
colors = lines(length(dims));

% Boyutların renklerine karşılık gelen etiketler
labels = cell(1, length(dims));
for i = 1:length(dims)
    labels{i} = sprintf('Dimension %d', dims(i));
end

% Tüm boyutların ortalamasının grafiğini çiz
figure;
hold on;
for dim_index = 1:length(dims)
    plot(avg_convergence_curves(dim_index, :), 'Color', colors(dim_index, :));
end
hold off;
title('Average Convergence Curve for All Dimensions');
xlabel('Iteration');
ylabel('Fitness Value');
legend(labels);
grid on;
% Kutu grafiği (box plot) çizdirme
figure;
boxplot(all_fitness_values', 'Labels', cellstr(num2str(dims')), 'Whisker', 1.5);
title('Box Plot of Fitness Values for Different Dimensions');
xlabel('Dimension');
ylabel('Fitness Value');
grid on;


% Fitness değerlerini toplamak için her boyuttaki toplam fitness değerlerini saklayacak bir matris oluştur
total_fitness_values = zeros(length(dims), 1);

% Her bir boyuttaki fitness değerlerini topla
for dim_index = 1:length(dims)
    total_fitness_values(dim_index) = sum(all_fitness_values(dim_index, :));
end

% Wilcoxon işaretli sıralama testi uygula ve sonuçları sakla
wilcoxon_results = cell(length(dims), 1);

for dim_index = 1:length(dims)
    % Wilcoxon işaretli sıralama testi uygula
    [~, p_value] = signrank(all_fitness_values(dim_index, :));
    
    % Sonucu sakla
    wilcoxon_results{dim_index} = struct('Dimension', dims(dim_index), 'Total_Fitness', sum(all_fitness_values(dim_index, :)), 'P_Value', p_value);
end

% Sonuçları tablo şeklinde göster
disp('Wilcoxon Signed Rank Test Results:');
disp('Dimension   Total_Fitness   P_Value');
for dim_index = 1:length(dims)
    disp([num2str(wilcoxon_results{dim_index}.Dimension), '          ', num2str(wilcoxon_results{dim_index}.Total_Fitness), '          ', num2str(wilcoxon_results{dim_index}.P_Value)]);
end

