function [y] = F2(x)
    % Fonksiyonun boyutunu al (D)
    D = length(x);
    
    % Toplamı başlat
    sum_term = 0;
    prod_term = 1;
    
    % Her bir bileşenin mutlak değerini al ve topla
    for i = 1:D
        sum_term = sum_term + abs(x(i));
        prod_term = prod_term * abs(x(i));
    end
    
    % Fonksiyon değerini hesapla
    y = sum_term + prod_term;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
