function y = F13(x)
    D = length(x);
    sum1 = 0;
    sum2 = 0;
    
    % Hesaplamalar
    for i = 1:(D - 1)
        sum1 = sum1 + (x(i) - 1)^2 * (1 + sin(3 * pi * x(i + 1))^2);
    end
    
    sum1 = sum1 + (x(D) - 1)^2 * (1 + sin(2 * pi * x(1))^2);
    
    for i = 1:D
        sum2 = sum2 + u(x(i), 5, 100, 4);
    end
    
    y = (1 / 10) * (sin(pi * x(1))^2 + sum1) + sum2;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end

function y = u(x, a, k, m)
    if abs(x) > a
        y = k * ((x - a)^(2 * m));
    else
        y = 0;
    end
end
