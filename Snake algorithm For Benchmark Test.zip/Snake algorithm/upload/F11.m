function [y] = F11(x)
    % x: D boyutlu vektör
    D = length(x);
    sum1 = 0;
    prod_cos = 1;
    for i = 1:D
        sum1 = sum1 + x(i)^2;
        prod_cos = prod_cos * cos(x(i) / sqrt(i));
    end
    term1 = 1/4000 * sum1;
    term2 = prod_cos;
    y = term1 - term2 + 1;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
