function [y] = F6(x)
    D = length(x); % Vektörün boyutunu al
    
    % Toplamı başlat
    sum = 0;
    
    % Terimleri topla
    for i = 1:D
        term = (floor(x(i) + 0.5))^2;
        sum = sum + term;
    end
    
    % Fonksiyon sonucunu sıfır ile maksimum al
    y = max(sum, 0);
end
