function [y] = F3(x)
    % Fonksiyonun boyutunu al (D)
    D = length(x);
    
    % Toplamı başlat
    sum = 0;
    
    % Her bir bileşen için işlem yap
    for i = 1:D
        % x_i + 0.5 değerini yuvarla ve karesini al
        rounded_x = round(x(i) + 0.5);
        squared_rounded_x = rounded_x^2;
        
        % Toplama ekle
        sum = sum + squared_rounded_x;
    end
    
    % Fonksiyon değerini döndür
    y = sum;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
