function objval = Chung_Reynolds(x)
    % Define the range for the variables
    lower_bound = -5.12;
    upper_bound = 5.12;
    
    % Ensure that the input vector 'x' is within the specified range
    x = max(x, lower_bound);
    x = min(x, upper_bound);
    
    % Calculate the objective value
    n = size(x, 2); 
    f = 0;
    for i = 1:n
        f = f + (x(i).^2).^2;
    end
    
    objval = f;
end
