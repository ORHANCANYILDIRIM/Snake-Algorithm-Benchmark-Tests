function [y] = F4(x)
    % Fonksiyonun boyutunu al
    D = length(x);
    
    % Mutlak değerlerin maksimumunu bul
    max_abs = max(abs(x));
    
  
    
    % Maksimum mutlak değeri fonksiyon sonucu olarak döndür
    y = max_abs;
    
    % Minimum değeri 0 yap
    y = max(y, 0);
end
