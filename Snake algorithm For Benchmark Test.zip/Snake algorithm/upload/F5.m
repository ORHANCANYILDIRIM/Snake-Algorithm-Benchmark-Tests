function [y] = F5(x)
    % Fonksiyonun boyutunu al
    D = length(x);
    
    % Toplamı başlat
    sum = 0;
    
    % Terimleri topla
    for i = 1:(D-1)
        term1 = 100 * (x(i+1) - x(i)^2)^2;
        term2 = (x(i) - 1)^2;
        sum = sum + term1 + term2;
    end
    
    % Toplamı fonksiyon sonucu olarak döndür
    y = sum;
    
    % Fonksiyonun minimum değerini 0 yap
    y = max(y, 0);
end
